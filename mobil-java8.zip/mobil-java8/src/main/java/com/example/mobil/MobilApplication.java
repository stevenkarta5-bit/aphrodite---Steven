package com.example.mobil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobilApplication {
  public static void main(String[] args) {
    SpringApplication.run(MobilApplication.class, args);
  }
}
